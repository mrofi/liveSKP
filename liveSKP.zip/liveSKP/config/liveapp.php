<?php 

return [
	'dateformat' => 'dd-MM-yyyy',
];