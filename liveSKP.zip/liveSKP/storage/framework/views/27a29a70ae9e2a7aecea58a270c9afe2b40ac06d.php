<?php if($errors->any()): ?>
<div class="alert alert-warning">
	<h4>Terjadi error</h4>
	<ul class="list-unstyled">
		<?php foreach($errors->all() as $error): ?>
			<li><?php echo e($error); ?></li>
		<?php endforeach; ?>
	</ul>
</div>
<?php endif; ?>