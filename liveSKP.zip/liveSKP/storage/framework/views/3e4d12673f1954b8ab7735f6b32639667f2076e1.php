<?php $__env->startSection('content'); ?>
<h4>
	<a href="<?php echo e(action($baseClass.'@getTambah')); ?>" class="btn btn-sm btn-success">Tambah</a> <small>Klik untuk menambah data <?php echo e($base); ?>.</small>
</h4>
<div class="box">
  	<div class="box-body">
		<table class="table datatables">
			<thead>
			<?php if(isset($datatablesFields)): ?>
		     	<?php foreach($datatablesFields as $field): ?>
				<th><?php echo e($field); ?></th>
				<?php endforeach; ?>
		    <?php else: ?>
				<?php foreach($fields as $field): ?>
				<th><?php echo e(ucwords(implode(' ', explode('_', $field)))); ?></th>
				<?php endforeach; ?>
			<?php endif; ?>
				<th>Menu</th>
			</thead>
		</table>  	  	
  	</div><!-- /.box-body -->
</div><!-- /.box-->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>