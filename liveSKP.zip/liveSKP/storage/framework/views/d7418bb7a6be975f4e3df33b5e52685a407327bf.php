<?php $__env->startSection('form'); ?>

	<?php echo $__env->make('partials.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('nip', 'NIP', ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::text('nip', $pns->nip, ['class' => 'form-control', 'readonly' => (!empty($pns->nip)) ? 'readonly' : null]); ?>

		</div>
	</div>

	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('nama', 'Nama PNS', ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::text('nama', $pns->nama, ['class' => 'form-control']); ?>

		</div>
	</div>

	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('alamat', 'Alamat', ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::text('alamat', $pns->alamat, ['class' => 'form-control']); ?>

		</div>
	</div>

	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('jenis_kelamin', 'Jenis Kelamin', ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::select('jenis_kelamin', [null => 'Pilih Jenis Kelamin'] + $jenis_kelamins, $pns->jenis_kelamin, ['class' => 'form-control']); ?>

		</div>
	</div>

	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('telp', 'Telp', ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::tel('telp', $pns->telp, ['class' => 'form-control']); ?>

		</div>
	</div>

	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('email', 'Email', ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::email('email', $pns->email, ['class' => 'form-control']); ?>

		</div>
	</div>
	
	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('tmt', 'TMT', ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::text('tmt', $pns->tmt, ['class' => 'form-control datepicker', 'onkeydown' => 'return false']); ?>

		</div>
	</div>
	
	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('jabatan', 'Jabatan', ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::select('jabatan', [null => 'Pilih Jabatan'] + $jabatans, $pns->jabatan_id, ['class' => 'form-control']); ?>

		</div>
	</div>

	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('dinas', 'Dinas', ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::select('dinas', [null => 'Pilih Dinas'] + $dinases, $pns->dinas_id, ['class' => 'form-control']); ?>

		</div>
	</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>