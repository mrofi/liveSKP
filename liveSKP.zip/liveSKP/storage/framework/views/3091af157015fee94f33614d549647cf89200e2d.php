
<?php echo $__env->make('themes.adminLTE.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>