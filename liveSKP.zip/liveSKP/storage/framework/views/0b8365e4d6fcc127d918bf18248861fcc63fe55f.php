<?php $__env->startSection('form'); ?>

	<?php echo $__env->make('partials.error', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('dinas', 'Nama Dinas', ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::text('dinas', $dinas->dinas, ['class' => 'form-control']); ?>

		</div>
	</div>

	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('alamat', null, ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::text('alamat', $dinas->alamat, ['class' => 'form-control']); ?>

		</div>
	</div>

	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('telp', null, ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::tel('telp', $dinas->telp, ['class' => 'form-control']); ?>

		</div>
	</div>

	<div class="row form-group">
		<div class="col-md-3">
			<?php echo Form::label('email', null, ['class' => 'control-label']); ?>

		</div>
		<div class="col-md-9">
			<?php echo Form::email('email', $dinas->email, ['class' => 'form-control']); ?>

		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.form', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>